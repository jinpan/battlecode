package team007;

public interface Message {
    
    public long encode();
    
    // TODO: figure out how to deal with static methods here
    // public static Message decode(int message);

}
