package team007;

import java.util.ArrayList;

import battlecode.common.*;

public class PastrPlayer extends BaseRobot{
	
    public PastrPlayer(RobotController myRC) throws GameActionException {
        super(myRC);
    }
    
    protected void step() throws GameActionException{
    	
    }
}
